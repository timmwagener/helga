

def helga_test_function():
	"""
		Helga test method
	"""

	print('If you can read this the module at {0} imported successfully...'.format(__file__))